package unirio.pixelated;

public class PixelatedBoard
{
	private String[] board;
	private int width;
	private int height;
	private int currentPosition;

	/**
	 * Inicializa um tabuleiro de Pixelated
	 * 
	 * @param width		Largura do tabuleiro
	 * @param height	Altura do tabuleiro
	 */
	public PixelatedBoard(int width, int height)
	{
		this(width, height, null);
	}

	/**
	 * Inicializa um tabuleiro de Pixelated
	 * 
	 * @param width		Largura do tabuleiro
	 * @param height	Altura do tabuleiro
	 * @param rows		Linhas com o conte�do do tabuleiro
	 */
	public PixelatedBoard(int width, int height, String[] rows)
	{
		this.width = width;
		this.height = height;
		this.board = new String[height];
		if (rows != null) setBoard(rows);
		this.currentPosition = 0;
	}
	
	/**
	 * Retorna a largura do tabuleiro
	 */
	public int getWidth()
	{
		return width;
	}
	
	/**
	 * Retorna a altura do tabuleiro
	 */
	public int getHeight()
	{
		return height;
	}
	
	/**
	 * Adiciona uma linha no tabuleiro
	 * 
	 * @param row	Linha que ser� adicionada
	 */
	public void addRow(String row)
	{
		setRow(currentPosition++, row);
	}

	/**
	 * Altera a linha de uma determinada posi��o do tabuleiro
	 * 
	 * @param position	Posi��o que ser� alterada
	 * @param row		Linha que ser� inserida na posi��o
	 */
	public void setRow(int position, String row)
	{
		if (row.length() == width && position >= 0 && position < height)
			this.board[position] = row;
	}

	/**
	 * Programa o tabuleiro
	 * 
	 * @param rows	Vetor de linhas do tabuleiro
	 */
	public void setBoard(String[] rows)
	{
		if (rows.length != height)
			return;
		
		for (int i = 0; i < rows.length; i++)
			setRow(i, rows[i]);
	}

	/**
	 * Retorna o tabuleiro
	 */
	public String[] getBoard()
	{
		return board;
	}
	
	/**
	 * Retorna a cor de uma posi��o do tabuleiro
	 * 
	 * @param x		Coordenada X da posi��o desejada
	 * @param y		Coordenada Y da posi��o desejada
	 */
	public char getColor(int x, int y)
	{
		return board[y].charAt(x);
	}

	/**
	 * Altera a cor de uma posi��o do tabuleiro
	 * 
	 * @param x		Coordenada X da posi��o que ser� alterada
	 * @param y		Coordenada Y da posi��o que ser� alterada
	 * @param color	Nova cor da posi��o indicada
	 */
	public void setColor(int x, int y, char color)
	{
		if (x == 0)
			board[y] = color + board[y].substring(1);
		else if (x == width-1)
			board[y] = board[y].substring(0, x) + color;
		else
			board[y] = board[y].substring(0, x) + color + board[y].substring(x+1);
	}
	
	/**
	 * Gera uma c�pia exata do tabuleiro
	 */
	public PixelatedBoard clone()
	{
		PixelatedBoard _board = new PixelatedBoard(this.width, this.height);
		
		for (int i = 0; i < this.height; i++)
			_board.addRow(board[i]);
		
		return _board;
	}

	/**
	 * Implementa��o do algoritmo de flood fill
	 * 
	 * @param x			Coordenada X do ponto original de pintura
	 * @param y			Coordenada Y do ponto original de pintura
	 * @param color		Cor com que a regi�o ser� pintada
	 */
	private void floodFill(int x, int y, char current, char color)
	{
	    if (getColor(x, y) == current)
	    {
			setColor(x, y, color);

			if (x > 0)
				floodFill(x-1, y, current, color);
			
			if (x < width-1)
				floodFill(x+1, y, current, color);

			if (y > 0)
				floodFill(x, y-1, current, color);
			
			if (y < height-1)
				floodFill(x, y+1, current, color);
	    }
	}

	/**
	 * Pinta o tabuleiro a partir de uma cor
	 * 
	 * @param color		Cor que ser� utilizada na pintura
	 */
	public void fill(char color)
	{
		char current = getColor(0, 0);
		
	    if (current != color)
	    	floodFill(0, 0, current, color);
	}

	/**
	 * Retorna o n�mero de cores do tabuleiro
	 */
	public int getColorCount()
	{
		String colors = "";
		int count = 0;
		
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				String color = "" + getColor(j, i);

				if (!colors.contains(color))
				{
					colors += color;
					count++;
				}
			}
		}
	
		return count;
	}

	/**
	 * Converte o tabuleiro para uma string
	 */
	public String toString()
	{
		String s = board[0];
		
		for (int i = 1; i < height; i++)
			s += '\n' + board[i];
		
		return s;
	}

	/**
	 * Aplica um caminho de cores sobre o tabuleiro
	 * 
	 * @param path		Caminho de solu��o
	 */
	public void apply(String path)
	{
		for (int i = 0; i < path.length(); i++)
		{
			if (path.charAt(i) == '*')
				break;
			
			fill(path.charAt(i));
		}
	}
}