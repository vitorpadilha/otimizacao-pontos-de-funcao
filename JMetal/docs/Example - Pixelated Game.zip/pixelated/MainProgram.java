package unirio.pixelated;

import java.io.IOException;
import unirio.utils.SeparatedFile;
import jmetal.base.Operator;
import jmetal.base.Solution;
import jmetal.base.SolutionSet;
import jmetal.base.operator.crossover.UniformCrossover;
import jmetal.base.operator.mutation.IntUniformMutation;
import jmetal.base.operator.selection.BinaryTournament;
import jmetal.metaheuristics.singleObjective.geneticAlgorithm.GANotifier;
import jmetal.metaheuristics.singleObjective.geneticAlgorithm.gGA;
import jmetal.util.JMException;

public class MainProgram
{
	protected static final int POPULATION = 10000;
	protected static final int ITERATIONS = 10000;
	protected static final int CYCLES = 1;

	public static final String[] FIRST_SAMPLE_BOARD = 
	{
		"GPOPYGOYOPGRPBYG",
		"BPGGYRYBYGYOORRG",
		"BOBYGROBPOGPPYYO",
		"YBPGPYOPOGGRYBPB",
		"OYPYRPOORGRPPGOO",
		"PRBOOORBBYGBROOG",
		"GYROPGGRROOYYGBO",
		"PGBBYRRRBRBRPRBY",
		"GBGOBBPBRRPYBGRY"
	};

	public static final String[] SECOND_SAMPLE_BOARD = 
	{
		"YRPRBGBOYOYRGPRG",
		"PYORGGPRPRGGPBOR",
		"YOGORROPGYGRYOPG",
		"OGGYGRORBYRGOBRY",
		"OPOYOBRBBYBYGGRY",
		"OYPROGRROBRPGGPG",
		"PPYPBPBBGYYPORRG",
		"POYGPYBYGOGOOBPY",
		"PGGPPBYBYRYGGGRB"
	};

	public static final String[] THIRD_SAMPLE_BOARD = 
	{
		"RRGY",
		"RRGY",
		"GGGY",
		"YYYY"
	};

	public static final String SAMPLE_COLORS = "RGBPOY";

	/**
	 * Programa principal
	 */
	public static void main(String[] args) throws SecurityException, IOException, ClassNotFoundException, JMException
	{
		new MainProgram().run();
	}

	/**
	 * Prepara e executa o algoritmo gen�tico
	 */
	public void run() throws SecurityException, IOException, ClassNotFoundException, JMException
	{
		String[] sample = SECOND_SAMPLE_BOARD;
		
		// Creating the problem
		PixelatedBoard board = new PixelatedBoard(sample[0].length(), sample.length, sample);
		PlayerProblem problem = new PlayerProblem(board, SAMPLE_COLORS, 30);

		// Crossover
		Operator crossover = new UniformCrossover();
		crossover.setParameter("probability", 1.0);

		// Mutation
		Operator mutation = new IntUniformMutation();
		mutation.setParameter("probability", 1.0 / problem.getNumberOfVariables());

		// Selection
		Operator selection = new BinaryTournament();

		// Configura��o do algoritmo
		gGA algorithm = new gGA(problem);
		algorithm.setInputParameter("populationSize", POPULATION);
		algorithm.setInputParameter("maxEvaluations", ITERATIONS * POPULATION);
		algorithm.addOperator("crossover", crossover);
		algorithm.addOperator("mutation", mutation);
		algorithm.addOperator("selection", selection);

		// Execute the algorithm
		SeparatedFile handle = new SeparatedFile("c:\\saida.txt");

		for (int i = 0; i < CYCLES; i++)
		{
			long initTime = System.currentTimeMillis();
			SolutionSet population = algorithm.execute(new GANotificator(problem));
			long estimatedTime = System.currentTimeMillis() - initTime;
			
			handle.write(i);
			handle.write(problem.solutionToString(population.get(0)));
			handle.write(population.get(0).getObjective(0));
			handle.newLine();

			System.out.println("Total execution time (" + i + "): " + estimatedTime + "ms");
		}

		handle.close();
	}
}

class GANotificator implements GANotifier
{
	private PlayerProblem problem;
	
	public GANotificator(PlayerProblem problem)
	{
		this.problem = problem;
	}
	
	@Override
	public void newIteration(int number, Solution best)
	{
		int iteration = number / MainProgram.POPULATION;

		try
		{
			problem.evaluate(best);
			System.out.print("Iteration #" + iteration + " ... ");
			System.out.print(problem.solutionToString(best) + " = " + best.getObjective(0));
			System.out.println();
		} 
		catch (JMException e)
		{
		}
	}
}