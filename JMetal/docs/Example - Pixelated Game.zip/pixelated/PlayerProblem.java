package unirio.pixelated;

import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.Variable;
import jmetal.base.solutionType.IntSolutionType;
import jmetal.util.JMException;

@SuppressWarnings("serial")
public class PlayerProblem extends Problem
{
	private PixelatedBoard board;
	private String colors; 

	public PlayerProblem(PixelatedBoard board, String colors, int maxRounds) throws ClassNotFoundException
	{
		this.board = board;
		this.colors = colors;

		numberOfVariables_ = maxRounds;
		numberOfObjectives_ = 1;
		numberOfConstraints_ = 0;

		setVariableLimits();
		solutionType_ = new IntSolutionType(this);
		variableType_ = new Class[numberOfVariables_];
		length_ = new int[numberOfVariables_];
		length_[0] = numberOfVariables_;
	}

	private void setVariableLimits()
	{
		upperLimit_ = new double[numberOfVariables_];
		lowerLimit_ = new double[numberOfVariables_];

		for (int i = 0; i < numberOfVariables_; i++)
		{
			lowerLimit_[i] = 0;
			upperLimit_[i] = colors.length();
		}
	}

	public String solutionToString(Solution solution) throws JMException
	{
		Variable[] sequence = solution.getDecisionVariables();
		String s = "";

		for (int i = 0; i < sequence.length; i++)
		{
			int colorNumber = (int) sequence[i].getValue();
			
			if (colorNumber == colors.length())
				s += "*";
			else
				s += colors.charAt(colorNumber);
		}
		
		return s;
	}

	public int getValidLength(String path)
	{
		for (int i = 0; i < path.length(); i++)
			if (path.charAt(i) == '*')
				return i;
		
		return path.length();
	}

	@Override
	public void evaluate(Solution solution) throws JMException
	{
		PixelatedBoard local = board.clone();
		String path = solutionToString(solution);
		int tamanho = getValidLength(path);
		local.apply(path);
		int cores = local.getColorCount();
		solution.setObjective(0, (cores-1) * 100 + tamanho);
	}
}