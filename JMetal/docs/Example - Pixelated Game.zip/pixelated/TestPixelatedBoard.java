package unirio.pixelated;

import junit.framework.TestCase;

public class TestPixelatedBoard extends TestCase
{
	public void checkBoards(String[] expected, String[] actual)
	{
		assertEquals(expected.length, actual.length);
		
		for (int i = 0; i < expected.length; i++)
			assertEquals(expected[i], actual[i]);
	}
	
	private void fillAndCompare(String[] antes, String[] depois, char fillColor)
	{
		PixelatedBoard board = new PixelatedBoard(4, 4, antes);
		board.fill(fillColor);
		checkBoards(depois, board.getBoard());
	}
	
	public void testFillVertical()
	{
		String[] vertical = {"GBBB", "GBBB", "GBBB", "GBBB" };
		String[] depois = {"BBBB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(vertical, depois, 'B');
	}

	public void testFillVerticalInterrupted()
	{
		String[] vertical = {"GBBB", "GBBB", "YBBB", "GBBB" };
		String[] depois = {"BBBB", "BBBB", "YBBB", "GBBB" };
		fillAndCompare(vertical, depois, 'B');
	}

	public void testFillHorizontal()
	{
		String[] horizontal = {"GGGG", "BBBB", "BBBB", "BBBB" };
		String[] depois = {"BBBB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(horizontal, depois, 'B');
	}

	public void testFillHorizontalInterrupted()
	{
		String[] horizontal = {"GGYB", "BBBB", "BBBB", "BBBB" };
		String[] depois = {"BBYB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(horizontal, depois, 'B');
	}

	public void testFillComplete()
	{
		String[] horizontal = {"GGGG", "GGGG", "GGGG", "GGGG" };
		String[] depois = {"BBBB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(horizontal, depois, 'B');
	}

	public void testFillBlock()
	{
		String[] horizontal = {"GGBB", "GGBB", "BBBB", "BBBB" };
		String[] depois = {"BBBB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(horizontal, depois, 'B');
	}

	public void testFillShifted()
	{
		String[] horizontal = {"GGBB", "BGGB", "BBBB", "BBBB" };
		String[] depois = {"BBBB", "BBBB", "BBBB", "BBBB" };
		fillAndCompare(horizontal, depois, 'B');
	}
}