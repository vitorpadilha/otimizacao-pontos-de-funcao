/**
 * TSP.java
 *
 * @author Antonio J. Nebro
 * @version 1.0
 */

package unirio.linear;

import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.solutionType.ArrayRealSolutionType;
import jmetal.base.variable.ArrayReal;

public class LinearParameters extends Problem
{
	private static final double[] X = new double[] { 1, 2, 3 };
	private static final double[] Y = new double[] { 1, 2, 3 };

	public LinearParameters() throws ClassNotFoundException
	{
		numberOfVariables_ = 2;
		numberOfObjectives_ = 1;
		numberOfConstraints_ = 0;
		problemName_ = "LinearParameters";

		upperLimit_ = new double[numberOfVariables_];
		lowerLimit_ = new double[numberOfVariables_];

		for (int i = 0; i < numberOfVariables_; i++)
		{
			lowerLimit_[i] = -1000.0;
			upperLimit_[i] = +1000.0;
		}

		solutionType_ = new ArrayRealSolutionType(this);
		variableType_ = new Class[numberOfVariables_];
		length_ = new int[numberOfVariables_];

		variableType_[0] = Class.forName("jmetal.base.variable.ArrayReal");
		length_[0] = 2;
	}

	public void evaluate(Solution solution)
	{
		double a = ((ArrayReal) solution.getDecisionVariables()[0]).array_[0];
		double b = ((ArrayReal) solution.getDecisionVariables()[0]).array_[1];

		double fitness = 0.0;

		for (int i = 0; i < X.length; i++)
			fitness += Math.pow(a * X[i] + b - Y[i], 2);

		solution.setObjective(0, fitness);
	}
}