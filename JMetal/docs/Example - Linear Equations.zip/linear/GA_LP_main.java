package unirio.linear;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import jmetal.base.Algorithm;
import jmetal.base.Operator;
import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.SolutionSet;
import jmetal.base.operator.crossover.CrossoverFactory;
import jmetal.base.operator.mutation.MutationFactory;
import jmetal.base.operator.selection.SelectionFactory;
import jmetal.base.variable.ArrayReal;
import jmetal.metaheuristics.singleObjective.geneticAlgorithm.ssGA;
import jmetal.util.Configuration;
import jmetal.util.JMException;

public class GA_LP_main
{
	public static void main(String[] args) throws JMException, ClassNotFoundException, SecurityException, IOException
	{
		Logger logger_ = Configuration.logger_ ;
	    FileHandler fileHandler_ = new FileHandler("GA_LP_main.log"); 
	    logger_.addHandler(fileHandler_) ;
		
		Problem problem = new LinearParameters();

		Operator crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover");
		crossover.setParameter("probability", 1.0);
		crossover.setParameter("distributionIndex", 20.0);

		Operator mutation = MutationFactory.getMutationOperator("PolynomialMutation");
		mutation.setParameter("probability", 1.0 / problem.getNumberOfVariables());
		mutation.setParameter("distributionIndex", 20.0);

		Operator selection = SelectionFactory.getSelectionOperator("BinaryTournament");

		Algorithm algorithm = new ssGA(problem);
		algorithm.setInputParameter("populationSize", 1000);
		algorithm.setInputParameter("maxEvaluations", 100000);
		algorithm.addOperator("crossover", crossover);
		algorithm.addOperator("mutation", mutation);
		algorithm.addOperator("selection", selection);

		long initTime = System.currentTimeMillis();
		System.out.println("Running ...");

		SolutionSet population = algorithm.execute();
		Solution best = population.get(0);
		ArrayReal variables = (ArrayReal) best.getDecisionVariables()[0];

		System.out.println("Run finished ..." + variables.array_[0] + ", " + variables.array_[1]);
		long estimatedTime = System.currentTimeMillis() - initTime;
		System.out.println("Total execution time: " + estimatedTime);
		
		
		logger_.info("Variables values have been writen to file VARIABLES");
	    population.printVariablesToFile("VARIABLES");    
	    logger_.info("Objectives values have been writen to file FUNCTIONS");
	    population.printObjectivesToFile("FUNCTIONS");
		
	}
}