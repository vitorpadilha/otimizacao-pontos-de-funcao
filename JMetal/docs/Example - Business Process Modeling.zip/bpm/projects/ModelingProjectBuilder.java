package unirio.bpm.projects;

import java.util.Vector;

public class ModelingProjectBuilder
{
	private static ModelingProjectBuilder instance = null;

	/**
	 * Inicializa um construtor de conjuntos de projetos de modelagem
	 */
	private ModelingProjectBuilder()
	{
	}

	/**
	 * Retorna a inst�ncia �nica do construtor de conjuntos de projetos
	 */
	public static ModelingProjectBuilder getInstance()
	{
		if (instance == null)
			instance = new ModelingProjectBuilder();

		return instance;
	}

	/**
	 * Retorna o conjunto de projetos administrativos
	 */
	public Vector<ModelingProject> getAdministrativeProjects()
	{
		Vector<ModelingProject> projects = new Vector<ModelingProject>();
		projects.addElement(new ModelingProject(5, 63, 14, 4, 13.44));
		projects.addElement(new ModelingProject(7, 48, 24, 4, 18.93));
		projects.addElement(new ModelingProject(9, 62, 28, 4, 24.53));
		projects.addElement(new ModelingProject(18, 95, 32, 2, 47.50));
		projects.addElement(new ModelingProject(8, 42, 34, 4, 12.72));
		projects.addElement(new ModelingProject(1, 103, 45, 4, 39.75));
		projects.addElement(new ModelingProject(10, 43, 49, 4, 12.31));
		projects.addElement(new ModelingProject(3, 82, 53, 5, 18.67));
		projects.addElement(new ModelingProject(4, 74, 60, 5, 16.17));
		projects.addElement(new ModelingProject(2, 90, 63, 5, 23.09));
		projects.addElement(new ModelingProject(15, 93, 71, 3, 64.08));
		projects.addElement(new ModelingProject(6, 132, 79, 4, 104.40));
		return projects;
	}
}