package unirio.bpm.projects;

public class ModelingProject
{
	private int id;
	private int duration;
	private int actvities;
	private int elements;
	private double adjustesDuration;

	/**
	 * Inicializa um projeto de modelagem
	 * 
	 * @param id Identificador do projeto
	 * @param duration Dura��o do projeto, em dias corridos
	 * @param actvities N�mero de atividades do projeto
	 * @param elements N�mero de elementos levantados durante o projeto
	 * @param adjustedDuration Tempo ajustado do projeto, em dias �teis
	 */
	public ModelingProject(int id, int duration, int actvities, int elements, double adjustedDuration)
	{
		this.id = id;
		this.duration = duration;
		this.actvities = actvities;
		this.elements = elements;
		this.adjustesDuration = adjustedDuration;
	}

	/**
	 * Retorna o identificador do projeot
	 */
	public int getId()
	{
		return id;
	}

	/**
	 * Retorna o tempo do projeto
	 */
	public int getDuration()
	{
		return duration;
	}

	/**
	 * Retorna o n�mero de atividades do processo
	 */
	public int getActvities()
	{
		return actvities;
	}

	/**
	 * Retorna o n�mero de elementos modelados no processo
	 * 
	 * @return
	 */
	public int getElements()
	{
		return elements;
	}

	/**
	 * Retorna o tempo ajustado do processo
	 */
	public double getAdjustedDuration()
	{
		return adjustesDuration;
	}
}