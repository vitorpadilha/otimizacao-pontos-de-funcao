package unirio.bpm.equations;

import unirio.bpm.projects.ModelingProject;
import jmetal.base.variable.ArrayReal;

public class FittingEquationPolinomial implements FittingEquation
{
	/**
	 * Retorna o n�mero de par�metros utilizados pela equa��o
	 */
	@Override
	public int getParameterCount()
	{
		return 5;
	}

	/**
	 * Retorna a dura��o estimada para um projeto, dados os par�metros da
	 * equa��o
	 * 
	 * @param parameters Par�metros da equa��o
	 * @param project Projeto sendo estimado
	 */
	@Override
	public double estimateProject(ArrayReal parameters, ModelingProject project)
	{
		double a = parameters.array_[0];
		double b = parameters.array_[1];
		double c = parameters.array_[2];
		double d = parameters.array_[3];
		double e = parameters.array_[4];

		int fad = project.getActvities();
		int neltos = project.getElements();
		return a * Math.pow(fad, 3) + b * Math.pow(fad, 2) + c * fad + d * neltos + e;
	}
}