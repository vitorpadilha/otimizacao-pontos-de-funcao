package unirio.bpm.equations;

import unirio.bpm.projects.ModelingProject;
import jmetal.base.variable.ArrayReal;

public interface FittingEquation
{
	/**
	 * Retorna o n�mero de par�metros utilizados pela equa��o
	 */
	int getParameterCount();

	/**
	 * Retorna a dura��o estimada para um projeto, dados os par�metros da
	 * equa��o
	 * 
	 * @param parameters Par�metros da equa��o
	 * @param project Projeto sendo estimado
	 */
	double estimateProject(ArrayReal parameters, ModelingProject project);
}