package unirio.bpm;

import java.text.DecimalFormat;
import java.util.Vector;
import jmetal.base.Operator;
import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.SolutionSet;
import jmetal.base.operator.crossover.CrossoverFactory;
import jmetal.base.operator.mutation.MutationFactory;
import jmetal.base.operator.selection.SelectionFactory;
import jmetal.base.variable.ArrayReal;
import jmetal.metaheuristics.singleObjective.geneticAlgorithm.GANotifier;
import jmetal.metaheuristics.singleObjective.geneticAlgorithm.gGA;
import jmetal.util.JMException;
import unirio.bpm.equations.FittingEquation;
import unirio.bpm.equations.FittingEquationPolinomial;
import unirio.bpm.projects.ModelingProject;
import unirio.bpm.projects.ModelingProjectBuilder;

public class MainProgram
{
	protected static final int INDIVIDUALS = 1000;
	protected static final int ITERATIONS = 1000000;
	private static DecimalFormat df = new DecimalFormat("0.000000");

	public static void main(String[] args) throws JMException, ClassNotFoundException
	{
		FittingEquation equation = new FittingEquationPolinomial();
		Vector<ModelingProject> projects = ModelingProjectBuilder.getInstance().getAdministrativeProjects();
		Problem problem = new GenericBPM(projects, equation);

		Operator crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover");
		crossover.setParameter("probability", 1.0);

		Operator mutation = MutationFactory.getMutationOperator("PolynomialMutation");
		mutation.setParameter("probability", 0.10);

		Operator selection = SelectionFactory.getSelectionOperator("BinaryTournament");

		gGA algorithm = new gGA(problem);
		algorithm.setInputParameter("populationSize", INDIVIDUALS);
		algorithm.setInputParameter("maxEvaluations", INDIVIDUALS * ITERATIONS);
		algorithm.addOperator("crossover", crossover);
		algorithm.addOperator("mutation", mutation);
		algorithm.addOperator("selection", selection);

		long initTime = System.currentTimeMillis();
		System.out.println("Running ...");

		SolutionSet population = algorithm.execute(new GANotificator());
		Solution best = population.get(0);
		ArrayReal variables = (ArrayReal) best.getDecisionVariables()[0];

		System.out.println("Run finished ...");
		printSolution(best);

		variables.array_[0] = 0.00136752073133454;
		variables.array_[1] = -0.15866730853646;
		variables.array_[2] = 5.82541919037467;
		variables.array_[3] = -10.1042720127775;
		variables.array_[4] = -3.68354764224766;
		problem.evaluate(best);
		System.out.println("Error = " + df.format(best.getObjective(0)));

		long estimatedTime = System.currentTimeMillis() - initTime;
		System.out.println("Total execution time: " + estimatedTime);
	}

	protected static void printSolution(Solution best)
	{
		ArrayReal variables = (ArrayReal) best.getDecisionVariables()[0];
		System.out.println("a = " + df.format(variables.array_[0]));
		System.out.println("b = " + df.format(variables.array_[1]));
		System.out.println("c = " + df.format(variables.array_[2]));
		System.out.println("d = " + df.format(variables.array_[3]));
		System.out.println("e = " + df.format(variables.array_[4]));
		System.out.println("Error = " + df.format(best.getObjective(0)));
	}
}

class GANotificator implements GANotifier
{
	@Override
	public void newIteration(int number, Solution best)
	{
		int iteration = number / MainProgram.INDIVIDUALS;

		if (iteration % 20 == 0)
		{
			System.out.println();
			System.out.println("Iteration #" + iteration + " ...");
			MainProgram.printSolution(best);
		}
	}
}