/**
 * TSP.java
 *
 * @author Antonio J. Nebro
 * @version 1.0
 */

package unirio.bpm;

import java.util.Vector;
import unirio.bpm.equations.FittingEquation;
import unirio.bpm.projects.ModelingProject;
import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.solutionType.ArrayRealSolutionType;
import jmetal.base.variable.ArrayReal;

public class GenericBPM extends Problem
{
	private Vector<ModelingProject> projects;

	private FittingEquation equation;

	public GenericBPM(Vector<ModelingProject> projects, FittingEquation equation) throws ClassNotFoundException
	{
		this.projects = projects;
		this.equation = equation;

		numberOfVariables_ = equation.getParameterCount();
		numberOfObjectives_ = 1;
		numberOfConstraints_ = 0;
		problemName_ = "ModelFitter";
		setVariableLimits(numberOfVariables_);
		solutionType_ = new ArrayRealSolutionType(this);
		variableType_ = new Class[numberOfVariables_];
		length_ = new int[numberOfVariables_];
		variableType_[0] = Class.forName("jmetal.base.variable.ArrayReal");
		length_[0] = numberOfVariables_;
	}

	private void setVariableLimits(int variableCount)
	{
		upperLimit_ = new double[variableCount];
		lowerLimit_ = new double[variableCount];

		for (int i = 0; i < variableCount; i++)
		{
			lowerLimit_[i] = -100.0;
			upperLimit_[i] = +100.0;
		}
	}

	public void evaluate(Solution solution)
	{
		ArrayReal parameters = (ArrayReal) solution.getDecisionVariables()[0];

		double fitness = 0.0;

		for (ModelingProject project : projects)
		{
			double erro = equation.estimateProject(parameters, project);
			fitness += Math.pow(erro - project.getAdjustedDuration(), 2);
		}

		solution.setObjective(0, fitness);
	}
}